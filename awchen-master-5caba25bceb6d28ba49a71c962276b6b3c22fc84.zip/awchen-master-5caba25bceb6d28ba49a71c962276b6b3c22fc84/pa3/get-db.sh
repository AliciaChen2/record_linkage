#!/bin/bash

echo "Getting database..."

wget -O ui/course-info.db https://www.classes.cs.uchicago.edu/archive/2016/winter/12200-1/pa/pa3/course_information.db

