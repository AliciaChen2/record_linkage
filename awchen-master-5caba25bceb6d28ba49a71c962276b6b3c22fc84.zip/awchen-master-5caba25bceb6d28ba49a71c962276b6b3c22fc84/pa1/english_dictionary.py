# CS122: Auto-completing keyboard using Tries
# Distribution
#
# Matthew Wachs
# Autumn 2014
#
# Revised: August 2015, AMR
#   December 2017, AMR
#
# Alicia Chen

import os
import sys
from sys import exit

import autocorrect_shell


class EnglishDictionary(object):
    def __init__(self, wordfile):
        '''
        Constructor

        Inputs:
          wordfile (string): name of the file with the words.
        '''
        self.words = TrieNode()

        with open(wordfile) as f:
            for w in f:
                w = w.strip()
                if w != "" and not self.is_word(w):
                    self.words.add_word(w)

    def is_word(self, w):
        '''
        Is the string a word?

        Inputs:
           w (string): the word to check

        Returns: boolean
        '''
        
        end_node = self.words.find_end(w)
        if end_node is None:
            return False
        else:
            return end_node.final

    def num_completions(self, prefix):
        '''
        How many words in the dictionary start with the specified
        prefix?

        Inputs:
          prefix (string): the prefix

        Returns: int
        '''
        # IMPORTANT: When you replace this version with the trie-based
        # version, do NOT compute the number of completions simply as
        #
        #    len(self.get_completions(prefix))
        #
        # See PA writeup for more details.

        end_node = self.words.find_end(prefix)
        if end_node is None:
            return 0
        else:
            return end_node.count

    def get_completions(self, prefix):
        '''
        Get the suffixes in the dictionary of words that start with the
        specified prefix.

        Inputs:
          prefix (string): the prefix

        Returns: list of strings.
        '''

        start_node = self.words.find_end(prefix)
        if start_node is None:
        	return []
        else:
        	return start_node.get_suffixes()

class TrieNode(object):
    def __init__(self, final=False, count=0):
        '''
        Constructor method. 
        Parameters:
        final: (Boolean) indicates if a word ends at the node
        count: (int) how many words contain the prefix
        '''

        self.count = count
        self.final = final
        self.children = {}

    def add_word(self, word):
        '''
        Adds a word to the Trie

        Inputs: 
        word: (string) word to be added to trie
        '''

        letter = word[0]
        self.count += 1

        if len(word) == 1:
            self.children[letter] = TrieNode(final=True, count=1)

        else:
            if letter not in self.children:
                self.children[letter] = TrieNode()
            self.children[letter].add_word(word[1:])

    def get_suffixes(self, text=""):
        '''
        Returns list of suffixes corresponding to node.
         
        Paremeters:
        text: (string) the suffix so far
        '''

        suffixes = []

        if self.final:
            suffixes.append(text)

        if not self.children:
            return suffixes

        else:
            for letter, child in self.children.items():
                suffixes = suffixes + child.get_suffixes(text + letter)
            return suffixes

    def find_end(self, word):
        '''
        Given a word that starts at the node, return the node that
        corresponds to the end of the word. If the given word does
        not exist for the node, return None.
        
        Parameters:
        word: (string) word that starts at the current node
        '''

        if len(word) == 0:
            return self
        letter = word[0]
        if letter not in self.children:
            return None
        if len(word) == 1:
            return self.children[letter]
        else:
            return self.children[letter].find_end(word[1:])


if __name__ == "__main__":
    autocorrect_shell.go("english_dictionary")
