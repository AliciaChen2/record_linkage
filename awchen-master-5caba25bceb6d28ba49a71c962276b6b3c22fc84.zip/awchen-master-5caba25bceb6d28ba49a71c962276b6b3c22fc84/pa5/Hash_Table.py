# CS122 W'19: Markov models and hash tables
# Alicia Chen


TOO_FULL = 0.5
GROWTH_RATIO = 2


def hash(string, m):
    '''
    Hash function that converts string to location in hash table
    '''
    hash_ = 0
    for char in string:
        hash_ = hash_ * 37
        hash_ = hash_ + ord(char)
        hash_ = hash_ % m
    return hash_


class Hash_Table:

    def __init__(self,cells,defval):
        '''
        Construct a new hash table with a fixed number of cells equal to the
        parameter "cells", and which yields the value defval upon a lookup to a
        key that has not previously been inserted
        '''
        # creating list of empty lists inspired by Dawny33 on 
        # https://stackoverflow.com/questions/33990673/
        self.cells = [[] for i in range(cells)]
        self.m = cells
        self.defval = defval
        self.filled = 0


    def lookup(self,key):
        '''
        Retrieve the value associated with the specified key in the hash table,
        or return the default value if it has not previously been inserted.
        '''
        hash_ = hash(key, self.m)
        for i in range(self.m):
            cell = self.cells[hash_]
            if cell:
                if cell[0] == key:
                    return cell[1]
                else:
                    if hash_ == self.m - 1:
                        hash_ = 0
                    else:
                        hash_ += 1
            else:
                return self.defval


    def rehash(self):
        '''
        If the fraction of occupied cells exceeds TOO_FULL, increase
        table size.
        '''
        new_table = Hash_Table(self.m * GROWTH_RATIO, self.defval)
        for cell in self.cells:
            if cell:
                new_table.update(cell[0], cell[1])

        self.cells = new_table.cells
        self.m = new_table.m
        self.filled = new_table.filled


    def update(self,key,val):
        '''
        Change the value associated with key "key" to value "val".
        If "key" is not currently present in the hash table,  insert it with
        value "val".
        '''
        hash_ = hash(key, self.m)
        # print(hash_)
        for i in range(self.m):
            cell = self.cells[hash_]
            if cell:
                if cell[0] == key:
                    self.cells[hash_][1] = val
                    # print(self.cells)
                    break
                else:
                    if hash_ == self.m - 1:
                        hash_ = 0
                    else:
                        hash_ += 1
            else:
                self.cells[hash_].append(key)
                self.cells[hash_].append(val)
                self.filled += 1
                # print(self.cells)
                if self.filled / self.m > TOO_FULL:
                    # print("REHASH")
                    self.rehash()
                break
