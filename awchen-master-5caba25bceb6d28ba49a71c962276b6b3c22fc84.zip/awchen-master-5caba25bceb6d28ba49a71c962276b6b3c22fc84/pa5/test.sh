#!/bin/bash

# echo "" > bush.txt
echo "" > kerry.txt
echo "" > obama.txt
echo "" > mccain.txt

## Bush

# for speech3 in `ls speeches/bush-kerry3/BUSH*`; do
#     python3 Markov.py speeches/bush1+2.txt speeches/kerry1+2.txt \
#     $speech3 2 >> bush.txt
# done

## Kerry

for speech3 in `ls speeches/bush-kerry3/KERRY*`; do
    python3 Markov.py speeches/bush1+2.txt speeches/kerry1+2.txt \
    $speech3 2 >> kerry.txt
done

## Obama

for speech3 in `ls speeches/obama-mccain3/OBAMA*`; do
    python3 Markov.py speeches/obama1+2.txt speeches/mccain1+2.txt \
    $speech3 2 >> obama.txt
done

## Mccain

for speech3 in `ls speeches/obama-mccain3/MCCAIN*`; do
    python3 Markov.py speeches/obama1+2.txt speeches/mccain1+2.txt \
    $speech3 2 >> mccain.txt
done
