CS 122: "The Markovian Candidate": Speaker Attribution Using Markov Models

Hash_Table.py: you will modify this file to implement a hash table
Markov.py: you will modify this file to implement a Markov model and to perform
           speaker attribution


speeches: contains sample text to use for testing
