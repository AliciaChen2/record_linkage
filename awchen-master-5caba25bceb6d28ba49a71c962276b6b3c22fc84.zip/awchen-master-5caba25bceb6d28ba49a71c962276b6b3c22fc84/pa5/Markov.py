# CS122 W'19: Markov models and hash tables
# Alicia Chen

import sys
import math
import Hash_Table

HASH_CELLS = 57


def find_ngrams(string, n):
    '''
    Given string, find every slice of the string with length n,
    including wrap-arounds

    Inputs:
     - string: (str) string to be sliced
     - n: (int) length of each n-gram
    '''
    ngrams = []
    for i, c in enumerate(string):
        if i < n - 1:
            ngram = string[-(n - i - 1):] + string[:i + 1]
            ngrams.append(ngram)
        else:
            ngrams.append(string[i - n + 1:i + 1])
        # print(ngrams)
    return ngrams


def freq_hash_table(l):
    '''
    Given list of strings, returns a hash table containing each string
    and its frequency in the list
    '''
    table = Hash_Table.Hash_Table(len(l), 0)
    for s in l:
        count = table.lookup(s)
        table.update(s, count + 1)
        # print(table.cells)
    return table


class Markov:


    def __init__(self,k,s):
        '''
        Construct a new k-order Markov model using the statistics of string "s"
        '''
        self.k = k
        k1_grams = find_ngrams(s, k + 1)
        # print(k1_grams)
        k_grams = find_ngrams(s, k)
        # print(k_grams)
        self.k1_table = freq_hash_table(k1_grams)
        self.k_table = freq_hash_table(k_grams)
        alph = set()
        for c in s:
            alph.add(c)
        self.S = len(alph)


    def log_probability(self,s):
        '''
        Get the log probability of string "s", given the statistics of
        character sequences modeled by this particular Markov model
        This probability is *not* normalized by the length of the string.
        '''
        ll = 0
        k1_grams = find_ngrams(s, self.k + 1)
        for k1_gram in k1_grams:
            k_gram = k1_gram[:-1]
            # print(k1_gram, k_gram)
            M = self.k1_table.lookup(k1_gram)
            N = self.k_table.lookup(k_gram)
            # print(M, N)
            ll += math.log((M + 1) / (N + self.S))
            # print(ll)
        return ll


def identify_speaker(speech1, speech2, speech3, order):
    '''
    Given sample text from two speakers, and text from an unidentified speaker,
    return a tuple with the *normalized* log probabilities of each of the speakers
    uttering that text under a "order" order character-based Markov model,
    and a conclusion of which speaker uttered the unidentified text
    based on the two probabilities.
    '''
    model_1 = Markov(order, speech1)
    model_2 = Markov(order, speech2)
    length = len(speech3)
    ll_1 = model_1.log_probability(speech3) / length
    ll_2 = model_2.log_probability(speech3) / length
    if ll_1 > ll_2:
        conclusion = "A"
    else:
        conclusion = "B"

    return (ll_1, ll_2, conclusion)


def print_results(res_tuple):
    '''
    Given a tuple from identify_speaker, print formatted results to the screen
    '''
    (likelihood1, likelihood2, conclusion) = res_tuple
    
    print("Speaker A: " + str(likelihood1))
    print("Speaker B: " + str(likelihood2))

    print("")

    print("Conclusion: Speaker " + conclusion + " is most likely")


if __name__=="__main__":
    num_args = len(sys.argv)

    if num_args != 5:
        print("usage: python3 " + sys.argv[0] + " <file name for speaker A> " +
              "<file name for speaker B>\n  <file name of text to identify> " +
              "<order>")
        sys.exit(0)
    
    with open(sys.argv[1], "rU") as file1:
        speech1 = file1.read()

    with open(sys.argv[2], "rU") as file2:
        speech2 = file2.read()

    with open(sys.argv[3], "rU") as file3:
        speech3 = file3.read()

    res_tuple = identify_speaker(speech1, speech2, speech3, int(sys.argv[4]))

    print_results(res_tuple)

