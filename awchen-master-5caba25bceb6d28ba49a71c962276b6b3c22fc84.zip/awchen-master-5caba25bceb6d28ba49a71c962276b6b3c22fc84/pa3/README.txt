CS 122: Course Search Engine: backend

get-db.sh: shell script to get the database.

ui: Django interface
  courses.py: you will modify this file.

  **** Do not modify these files ****
    db.sqlite3
    manage.py
    res
    search
    static
    ui
