import bs4
import urllib3
import certifi
import csv

def current_weather(airport):
    myurl = "https://www.aviationweather.gov/metar/data?ids=" + airport + "&format=raw&date=&hours=0"

    pm = urllib3.PoolManager(
       cert_reqs='CERT_REQUIRED',
       ca_certs=certifi.where())
    html = pm.urlopen(url=myurl, method="GET").data

    soup = bs4.BeautifulSoup(html, features="lxml")
    tag = soup.find_all("code")[0]
    data = tag.text

    return data


######

def weather_to_csv(url, file_name):

    pm = urllib3.PoolManager(cert_reqs='CERT_REQUIRED', ca_certs=certifi.where())
    html = pm.urlopen(url=url, method="GET").data

    soup = bs4.BeautifulSoup(html, features="lxml")
    table = soup.find_all("table", id="monthlyClimate")[0]
    rows = table.find_all("tr")
    
    data = []
    for row in rows:
        row_data_tags = row.find_all("td")
        row_data = []
        for tag in row_data_tags:
            if tag.find_all("a") is not None:
                row_data.append(tag.find_all("a")[0].text)
            row_data.append(tag.text)
        data.append(row)

    with open(file_name, mode="w") as file:
        writer = csv.writer(file, delimiter=",")
        for csv_row in data:
            writer.writerow(csv_row)